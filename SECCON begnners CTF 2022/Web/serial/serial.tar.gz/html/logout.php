<?php

require_once '/var/www/html/user.php';

logout();
header("Location: /");