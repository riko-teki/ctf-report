REVOKE ALL PRIVILEGES ON `serial`.* FROM 'ctf4b'@'%';
GRANT SELECT, INSERT, UPDATE ON `serial`.* TO 'ctf4b'@'%';